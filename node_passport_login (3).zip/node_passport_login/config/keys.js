dbPassword = 'mongodb+srv://username:'+ encodeURIComponent('password') + '@clusterO-jtpxd.mongodb.net/admin';

module.exports = {
    mongoURI: dbPassword
};